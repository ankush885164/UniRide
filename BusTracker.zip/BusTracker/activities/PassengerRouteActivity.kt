package com.university.bustracker.activities

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.university.bustracker.R
import com.university.bustracker.model.BusRoute

class PassengerRouteActivity : AppCompatActivity() {
    
    private lateinit var recyclerView: RecyclerView
    private lateinit var routeAdapter: RouteAdapter
    
    private val routes = listOf(
        BusRoute(
            id = 1,
            number = "Route 1",
            name = "Main Campus → North Dorms",
            stops = listOf("Main Gate", "Admin Block", "Library", "Student Center", "Engineering Block", "North Dorms"),
            frequency = "Every 15 min",
            etaMinutes = 3,
            isActive = true,
            busId = "BUS-101"
        ),
        BusRoute(
            id = 2,
            number = "Route 2",
            name = "Main Campus → South Dorms",
            stops = listOf("Main Gate", "Science Block", "Medical Center", "Arts Building", "South Dorms"),
            frequency = "Every 20 min",
            etaMinutes = 8,
            isActive = true,
            busId = "BUS-202"
        ),
        BusRoute(
            id = 3,
            number = "Route 3",
            name = "Library → Sports Complex",
            stops = listOf("Library", "Canteen", "Stadium Road", "Sports Complex"),
            frequency = "Every 10 min",
            etaMinutes = 12,
            isActive = true,
            busId = "BUS-303"
        ),
        BusRoute(
            id = 4,
            number = "Route 4",
            name = "Downtown Express",
            stops = listOf("Main Gate", "City Center", "Mall", "Transit Hub", "University Square", "Downtown"),
            frequency = "Every 30 min",
            etaMinutes = null,
            isActive = false,
            busId = "BUS-404"
        )
    )
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_passenger_route)
        
        setupRecyclerView()
    }
    
    private fun setupRecyclerView() {
        recyclerView = findViewById(R.id.recycler_routes)
        recyclerView.layoutManager = LinearLayoutManager(this)
        
        routeAdapter = RouteAdapter(routes) { route ->
            onRouteSelected(route)
        }
        recyclerView.adapter = routeAdapter
    }
    
    private fun onRouteSelected(route: BusRoute) {
        if (!route.isActive) {
            Toast.makeText(this, "This route is currently inactive", Toast.LENGTH_SHORT).show()
            return
        }
        
        val intent = Intent(this, PassengerMapActivity::class.java).apply {
            putExtra("ROUTE_ID", route.id)
            putExtra("ROUTE_NUMBER", route.number)
            putExtra("ROUTE_NAME", route.name)
            putExtra("BUS_ID", route.busId)
            putExtra("ETA_MINUTES", route.etaMinutes ?: 0)
        }
        startActivity(intent)
    }
    
    // RecyclerView Adapter
    inner class RouteAdapter(
        private val routes: List<BusRoute>,
        private val onRouteClick: (BusRoute) -> Unit
    ) : RecyclerView.Adapter<RouteAdapter.RouteViewHolder>() {
        
        inner class RouteViewHolder(view: View) : RecyclerView.ViewHolder(view) {
            val cardView: CardView = view.findViewById(R.id.card_route)
            val tvRouteNumber: TextView = view.findViewById(R.id.tv_route_number)
            val tvRouteName: TextView = view.findViewById(R.id.tv_route_name)
            val tvFrequency: TextView = view.findViewById(R.id.tv_frequency)
            val tvStops: TextView = view.findViewById(R.id.tv_stops)
            val tvETA: TextView = view.findViewById(R.id.tv_eta)
            val tvStatus: TextView = view.findViewById(R.id.tv_status)
        }
        
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RouteViewHolder {
            val view = LayoutInflater.from(parent.context)
                .inflate(R.layout.item_route_card, parent, false)
            return RouteViewHolder(view)
        }
        
        override fun onBindViewHolder(holder: RouteViewHolder, position: Int) {
            val route = routes[position]
            
            holder.tvRouteNumber.text = route.number
            holder.tvRouteName.text = route.name
            holder.tvFrequency.text = "🕐 ${route.frequency}"
            holder.tvStops.text = "🚏 ${route.stops.size} stops"
            
            if (route.isActive && route.etaMinutes != null) {
                holder.tvETA.text = "${route.etaMinutes} min"
                holder.tvETA.visibility = View.VISIBLE
                holder.tvStatus.text = "● Active"
                holder.tvStatus.setTextColor(holder.itemView.context.getColor(android.R.color.holo_green_dark))
                holder.cardView.alpha = 1.0f
            } else {
                holder.tvETA.visibility = View.GONE
                holder.tvStatus.text = "● Inactive"
                holder.tvStatus.setTextColor(holder.itemView.context.getColor(android.R.color.holo_red_dark))
                holder.cardView.alpha = 0.6f
            }
            
            holder.cardView.setOnClickListener {
                onRouteClick(route)
            }
        }
        
        override fun getItemCount() = routes.size
    }
}
