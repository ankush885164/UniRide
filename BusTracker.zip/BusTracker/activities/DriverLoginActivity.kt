package com.university.bustracker.activities

import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.textfield.TextInputEditText
import com.university.bustracker.R

class DriverLoginActivity : AppCompatActivity() {
    
    private lateinit var etDriverId: TextInputEditText
    private lateinit var etPassword: TextInputEditText
    private lateinit var spinnerRoute: Spinner
    private lateinit var btnLogin: Button
    private lateinit var tvError: TextView
    private lateinit var progressBar: ProgressBar
    
    // Mock driver credentials (in production, this would be validated via backend)
    private val validDrivers = mapOf(
        "D001" to "1234",
        "D002" to "5678",
        "D003" to "abcd"
    )
    
    private val routes = arrayOf(
        "Select Route",
        "Route 1 - Main Campus → North Dorms",
        "Route 2 - Main Campus → South Dorms",
        "Route 3 - Library → Sports Complex",
        "Route 4 - Downtown Express"
    )
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_driver_login)
        
        initializeViews()
        setupRouteSpinner()
        setupClickListeners()
    }
    
    private fun initializeViews() {
        etDriverId = findViewById(R.id.et_driver_id)
        etPassword = findViewById(R.id.et_password)
        spinnerRoute = findViewById(R.id.spinner_route)
        btnLogin = findViewById(R.id.btn_login)
        tvError = findViewById(R.id.tv_error)
        progressBar = findViewById(R.id.progress_bar)
    }
    
    private fun setupRouteSpinner() {
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, routes)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerRoute.adapter = adapter
    }
    
    private fun setupClickListeners() {
        btnLogin.setOnClickListener {
            validateAndLogin()
        }
    }
    
    private fun validateAndLogin() {
        val driverId = etDriverId.text.toString().trim()
        val password = etPassword.text.toString().trim()
        val selectedRoute = spinnerRoute.selectedItemPosition
        
        // Clear previous error
        tvError.visibility = TextView.GONE
        
        // Validate inputs
        when {
            driverId.isEmpty() -> {
                showError("Please enter Driver ID")
                return
            }
            password.isEmpty() -> {
                showError("Please enter password")
                return
            }
            selectedRoute == 0 -> {
                showError("Please select a route")
                return
            }
            !validDrivers.containsKey(driverId) || validDrivers[driverId] != password -> {
                showError("Invalid credentials. Try ID: D001 / Pass: 1234")
                return
            }
        }
        
        // Simulate login process
        progressBar.visibility = ProgressBar.VISIBLE
        btnLogin.isEnabled = false
        
        // Navigate to driver map after short delay
        btnLogin.postDelayed({
            progressBar.visibility = ProgressBar.GONE
            btnLogin.isEnabled = true
            navigateToDriverMap(driverId, routes[selectedRoute])
        }, 1000)
    }
    
    private fun showError(message: String) {
        tvError.text = message
        tvError.visibility = TextView.VISIBLE
    }
    
    private fun navigateToDriverMap(driverId: String, route: String) {
        val intent = Intent(this, DriverMapActivity::class.java).apply {
            putExtra("DRIVER_ID", driverId)
            putExtra("ROUTE", route)
        }
        startActivity(intent)
        finish()
    }
    
    override fun onBackPressed() {
        super.onBackPressed()
        finish()
    }
}
