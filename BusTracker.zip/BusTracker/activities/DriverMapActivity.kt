package com.university.bustracker.activities

import android.Manifest
import android.content.pm.PackageManager
import android.location.Location
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.gms.location.*
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.*
import com.google.android.material.textfield.TextInputEditText
import com.university.bustracker.R

class DriverMapActivity : AppCompatActivity(), OnMapReadyCallback {
    
    private lateinit var googleMap: GoogleMap
    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private lateinit var locationCallback: LocationCallback
    private var currentLocationMarker: Marker? = null
    
    private lateinit var tvDriverName: TextView
    private lateinit var tvRouteInfo: TextView
    private lateinit var tvLocationStatus: TextView
    private lateinit var etETA: TextInputEditText
    private lateinit var spinnerNextStop: Spinner
    private lateinit var spinnerOccupancy: Spinner
    private lateinit var btnUpdateETA: Button
    private lateinit var btnEndShift: Button
    
    private var driverId: String = ""
    private var routeInfo: String = ""
    
    private val LOCATION_PERMISSION_REQUEST = 1001
    
    private val stops = arrayOf(
        "Main Gate",
        "Library",
        "Student Center",
        "Engineering Block",
        "North Dorms",
        "South Dorms",
        "Sports Complex",
        "Medical Center"
    )
    
    private val occupancyLevels = arrayOf(
        "Empty (0-10)",
        "Low (10-20)",
        "Medium (20-35)",
        "High (35-45)",
        "Full (45+)"
    )
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_driver_map)
        
        // Get driver info from intent
        driverId = intent.getStringExtra("DRIVER_ID") ?: "Unknown"
        routeInfo = intent.getStringExtra("ROUTE") ?: "Unknown Route"
        
        initializeViews()
        setupSpinners()
        setupClickListeners()
        setupMap()
        
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)
    }
    
    private fun initializeViews() {
        tvDriverName = findViewById(R.id.tv_driver_name)
        tvRouteInfo = findViewById(R.id.tv_route_info)
        tvLocationStatus = findViewById(R.id.tv_location_status)
        etETA = findViewById(R.id.et_eta)
        spinnerNextStop = findViewById(R.id.spinner_next_stop)
        spinnerOccupancy = findViewById(R.id.spinner_occupancy)
        btnUpdateETA = findViewById(R.id.btn_update_eta)
        btnEndShift = findViewById(R.id.btn_end_shift)
        
        tvDriverName.text = "Driver $driverId"
        tvRouteInfo.text = routeInfo
    }
    
    private fun setupSpinners() {
        val stopAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, stops)
        stopAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerNextStop.adapter = stopAdapter
        
        val occupancyAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, occupancyLevels)
        occupancyAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerOccupancy.adapter = occupancyAdapter
        spinnerOccupancy.setSelection(2) // Default to "Medium"
    }
    
    private fun setupClickListeners() {
        btnUpdateETA.setOnClickListener {
            broadcastUpdate()
        }
        
        btnEndShift.setOnClickListener {
            confirmEndShift()
        }
    }
    
    private fun setupMap() {
        val mapFragment = supportFragmentManager
            .findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)
    }
    
    override fun onMapReady(map: GoogleMap) {
        googleMap = map
        googleMap.uiSettings.apply {
            isZoomControlsEnabled = true
            isMyLocationButtonEnabled = false
            isCompassEnabled = true
        }
        
        checkLocationPermission()
    }
    
    private fun checkLocationPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
            == PackageManager.PERMISSION_GRANTED) {
            startLocationUpdates()
        } else {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
                LOCATION_PERMISSION_REQUEST
            )
        }
    }
    
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == LOCATION_PERMISSION_REQUEST) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                startLocationUpdates()
            } else {
                tvLocationStatus.text = "❌ Location permission denied"
                Toast.makeText(this, "Location permission is required", Toast.LENGTH_LONG).show()
            }
        }
    }
    
    private fun startLocationUpdates() {
        val locationRequest = LocationRequest.create().apply {
            interval = 5000 // 5 seconds
            fastestInterval = 3000
            priority = LocationRequest.PRIORITY_HIGH_ACCURACY
        }
        
        locationCallback = object : LocationCallback() {
            override fun onLocationResult(locationResult: LocationResult) {
                locationResult.lastLocation?.let { location ->
                    updateLocationOnMap(location)
                }
            }
        }
        
        if (ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            fusedLocationClient.requestLocationUpdates(
                locationRequest,
                locationCallback,
                mainLooper
            )
            tvLocationStatus.text = "✅ GPS Active - Broadcasting Location"
        }
    }
    
    private fun updateLocationOnMap(location: Location) {
        val latLng = LatLng(location.latitude, location.longitude)
        
        if (currentLocationMarker == null) {
            currentLocationMarker = googleMap.addMarker(
                MarkerOptions()
                    .position(latLng)
                    .title("Your Bus")
                    .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_GREEN))
            )
            googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng, 16f))
        } else {
            currentLocationMarker?.position = latLng
        }
        
        // In production, send location to backend here
        // sendLocationToServer(location.latitude, location.longitude)
    }
    
    private fun broadcastUpdate() {
        val eta = etETA.text.toString()
        val nextStop = spinnerNextStop.selectedItem.toString()
        val occupancy = spinnerOccupancy.selectedItem.toString()
        
        if (eta.isEmpty()) {
            Toast.makeText(this, "Please enter ETA", Toast.LENGTH_SHORT).show()
            return
        }
        
        // In production, send update to backend
        // updateBackend(eta, nextStop, occupancy)
        
        Toast.makeText(
            this,
            "📡 Update Sent\nETA: $eta min to $nextStop\nOccupancy: $occupancy",
            Toast.LENGTH_LONG
        ).show()
    }
    
    private fun confirmEndShift() {
        AlertDialog.Builder(this)
            .setTitle("End Shift")
            .setMessage("Are you sure you want to end your shift?")
            .setPositiveButton("Yes") { _, _ ->
                endShift()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
    
    private fun endShift() {
        fusedLocationClient.removeLocationUpdates(locationCallback)
        Toast.makeText(this, "Shift ended. Drive safe!", Toast.LENGTH_SHORT).show()
        finish()
    }
    
    override fun onDestroy() {
        super.onDestroy()
        fusedLocationClient.removeLocationUpdates(locationCallback)
    }
}
