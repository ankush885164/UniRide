package com.university.bustracker.activities

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Color
import android.location.Location
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.gms.location.*
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.*
import com.google.android.material.card.MaterialCardView
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.university.bustracker.R

class PassengerMapActivity : AppCompatActivity(), OnMapReadyCallback {
    
    private lateinit var googleMap: GoogleMap
    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private var myLocationMarker: Marker? = null
    private var busMarker: Marker? = null
    private var routePolyline: Polyline? = null
    private val stopMarkers = mutableListOf<Marker>()
    
    private lateinit var tvRouteNumber: TextView
    private lateinit var tvRouteName: TextView
    private lateinit var tvBusId: TextView
    private lateinit var tvStatus: TextView
    private lateinit var tvETA: TextView
    private lateinit var tvNextStop: TextView
    private lateinit var tvOccupancy: TextView
    private lateinit var cardBusInfo: MaterialCardView
    private lateinit var fabMyLocation: FloatingActionButton
    private lateinit var fabBusLocation: FloatingActionButton
    
    private var routeId: Int = 0
    private var routeNumber: String = ""
    private var routeName: String = ""
    private var busId: String = ""
    private var etaMinutes: Int = 0
    
    private val LOCATION_PERMISSION_REQUEST = 2001
    private val handler = Handler(Looper.getMainLooper())
    private var etaCountdownRunnable: Runnable? = null
    
    // Mock route coordinates (in production, fetch from backend)
    private val routeCoordinates = mapOf(
        1 to listOf(
            LatLng(40.7138, -74.0060),
            LatLng(40.7130, -74.0040),
            LatLng(40.7120, -74.0020),
            LatLng(40.7115, -74.0005),
            LatLng(40.7105, -73.9990),
            LatLng(40.7095, -73.9975)
        ),
        2 to listOf(
            LatLng(40.7138, -74.0060),
            LatLng(40.7125, -74.0080),
            LatLng(40.7110, -74.0100),
            LatLng(40.7095, -74.0115),
            LatLng(40.7080, -74.0130)
        ),
        3 to listOf(
            LatLng(40.7120, -74.0020),
            LatLng(40.7110, -74.0000),
            LatLng(40.7100, -73.9985),
            LatLng(40.7090, -73.9970)
        )
    )
    
    private val stopNames = mapOf(
        1 to listOf("Main Gate", "Admin Block", "Library", "Student Center", "Engineering Block", "North Dorms"),
        2 to listOf("Main Gate", "Science Block", "Medical Center", "Arts Building", "South Dorms"),
        3 to listOf("Library", "Canteen", "Stadium Road", "Sports Complex")
    )
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_passenger_map)
        
        // Get route info from intent
        routeId = intent.getIntExtra("ROUTE_ID", 1)
        routeNumber = intent.getStringExtra("ROUTE_NUMBER") ?: "Route 1"
        routeName = intent.getStringExtra("ROUTE_NAME") ?: "Unknown Route"
        busId = intent.getStringExtra("BUS_ID") ?: "BUS-101"
        etaMinutes = intent.getIntExtra("ETA_MINUTES", 5)
        
        initializeViews()
        setupClickListeners()
        setupMap()
        
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)
    }
    
    private fun initializeViews() {
        tvRouteNumber = findViewById(R.id.tv_route_number)
        tvRouteName = findViewById(R.id.tv_route_name)
        tvBusId = findViewById(R.id.tv_bus_id)
        tvStatus = findViewById(R.id.tv_status)
        tvETA = findViewById(R.id.tv_eta)
        tvNextStop = findViewById(R.id.tv_next_stop)
        tvOccupancy = findViewById(R.id.tv_occupancy)
        cardBusInfo = findViewById(R.id.card_bus_info)
        fabMyLocation = findViewById(R.id.fab_my_location)
        fabBusLocation = findViewById(R.id.fab_bus_location)
        
        tvRouteNumber.text = routeNumber
        tvRouteName.text = routeName
        tvBusId.text = busId
        tvStatus.text = "En Route"
        tvETA.text = "$etaMinutes min"
        tvNextStop.text = stopNames[routeId]?.get(1) ?: "Main Gate"
        tvOccupancy.text = "Medium (20-35)"
    }
    
    private fun setupClickListeners() {
        fabMyLocation.setOnClickListener {
            centerOnMyLocation()
        }
        
        fabBusLocation.setOnClickListener {
            centerOnBusLocation()
        }
    }
    
    private fun setupMap() {
        val mapFragment = supportFragmentManager
            .findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)
    }
    
    override fun onMapReady(map: GoogleMap) {
        googleMap = map
        googleMap.uiSettings.apply {
            isZoomControlsEnabled = false
            isMyLocationButtonEnabled = false
            isCompassEnabled = true
        }
        
        drawRoute()
        addStopMarkers()
        addBusMarker()
        checkLocationPermission()
        startETACountdown()
    }
    
    private fun drawRoute() {
        val coordinates = routeCoordinates[routeId] ?: return
        
        routePolyline = googleMap.addPolyline(
            PolylineOptions()
                .addAll(coordinates)
                .color(Color.parseColor("#4285F4"))
                .width(10f)
                .geodesic(true)
        )
        
        // Move camera to show route
        val builder = LatLngBounds.Builder()
        coordinates.forEach { builder.include(it) }
        val bounds = builder.build()
        googleMap.animateCamera(CameraUpdateFactory.newLatLngBounds(bounds, 150))
    }
    
    private fun addStopMarkers() {
        val coordinates = routeCoordinates[routeId] ?: return
        val names = stopNames[routeId] ?: return
        
        coordinates.forEachIndexed { index, latLng ->
            val marker = googleMap.addMarker(
                MarkerOptions()
                    .position(latLng)
                    .title(names.getOrNull(index) ?: "Stop ${index + 1}")
                    .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_ORANGE))
            )
            marker?.let { stopMarkers.add(it) }
        }
    }
    
    private fun addBusMarker() {
        val coordinates = routeCoordinates[routeId] ?: return
        if (coordinates.isEmpty()) return
        
        // Start bus at first coordinate
        val busPosition = coordinates[0]
        busMarker = googleMap.addMarker(
            MarkerOptions()
                .position(busPosition)
                .title(busId)
                .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_AZURE))
        )
        
        // Animate bus along route
        animateBusAlongRoute(coordinates)
    }
    
    private fun animateBusAlongRoute(coordinates: List<LatLng>) {
        if (coordinates.size < 2) return
        
        var currentIndex = 0
        val animationHandler = Handler(Looper.getMainLooper())
        
        val animateRunnable = object : Runnable {
            override fun run() {
                if (currentIndex < coordinates.size) {
                    busMarker?.position = coordinates[currentIndex]
                    currentIndex++
                    animationHandler.postDelayed(this, 3000) // Move every 3 seconds
                } else {
                    currentIndex = 0 // Loop back
                    animationHandler.postDelayed(this, 3000)
                }
            }
        }
        
        animationHandler.post(animateRunnable)
    }
    
    private fun checkLocationPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
            == PackageManager.PERMISSION_GRANTED) {
            enableMyLocation()
        } else {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
                LOCATION_PERMISSION_REQUEST
            )
        }
    }
    
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == LOCATION_PERMISSION_REQUEST) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                enableMyLocation()
            }
        }
    }
    
    private fun enableMyLocation() {
        if (ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            fusedLocationClient.lastLocation.addOnSuccessListener { location: Location? ->
                location?.let {
                    val myLatLng = LatLng(it.latitude, it.longitude)
                    myLocationMarker = googleMap.addMarker(
                        MarkerOptions()
                            .position(myLatLng)
                            .title("Your Location")
                            .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_GREEN))
                    )
                }
            }
        }
    }
    
    private fun centerOnMyLocation() {
        myLocationMarker?.let {
            googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(it.position, 16f))
        } ?: Toast.makeText(this, "Location not available", Toast.LENGTH_SHORT).show()
    }
    
    private fun centerOnBusLocation() {
        busMarker?.let {
            googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(it.position, 16f))
        }
    }
    
    private fun startETACountdown() {
        var currentETA = etaMinutes
        
        etaCountdownRunnable = object : Runnable {
            override fun run() {
                if (currentETA > 0) {
                    currentETA--
                    tvETA.text = if (currentETA == 0) "Arriving!" else "$currentETA min"
                    
                    if (currentETA == 1) {
                        Toast.makeText(
                            this@PassengerMapActivity,
                            "🔔 Bus arriving in 1 minute!",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                    
                    handler.postDelayed(this, 60000) // 1 minute
                } else {
                    tvETA.text = "Arrived"
                    tvStatus.text = "At Stop"
                }
            }
        }
        
        handler.post(etaCountdownRunnable!!)
    }
    
    override fun onDestroy() {
        super.onDestroy()
        etaCountdownRunnable?.let { handler.removeCallbacks(it) }
    }
}
