package com.university.bustracker.activities

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import com.university.bustracker.R

class RoleSelectActivity : AppCompatActivity() {
    
    private lateinit var btnDriver: Button
    private lateinit var btnPassenger: Button
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_role_select)
        
        initializeViews()
        setupClickListeners()
    }
    
    private fun initializeViews() {
        btnDriver = findViewById(R.id.btn_driver)
        btnPassenger = findViewById(R.id.btn_passenger)
    }
    
    private fun setupClickListeners() {
        btnDriver.setOnClickListener {
            navigateToDriverLogin()
        }
        
        btnPassenger.setOnClickListener {
            navigateToPassengerRoute()
        }
    }
    
    private fun navigateToDriverLogin() {
        val intent = Intent(this, DriverLoginActivity::class.java)
        startActivity(intent)
    }
    
    private fun navigateToPassengerRoute() {
        val intent = Intent(this, PassengerRouteActivity::class.java)
        startActivity(intent)
    }
}
