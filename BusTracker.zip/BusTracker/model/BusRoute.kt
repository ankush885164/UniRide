package com.university.bustracker.model

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class BusRoute(
    val id: Int,
    val number: String,
    val name: String,
    val stops: List<String>,
    val frequency: String,
    val etaMinutes: Int?,
    val isActive: Boolean,
    val busId: String
) : Parcelable

data class BusLocation(
    val busId: String,
    val latitude: Double,
    val longitude: Double,
    val timestamp: Long,
    val speed: Float = 0f,
    val bearing: Float = 0f
)

data class BusStatus(
    val busId: String,
    val routeId: Int,
    val currentStop: String,
    val nextStop: String,
    val etaMinutes: Int,
    val occupancy: String,
    val isActive: Boolean,
    val lastUpdated: Long
)

data class Driver(
    val driverId: String,
    val name: String,
    val phoneNumber: String,
    val assignedRoute: String,
    val isOnDuty: Boolean
)
